"""
    Step1. 진단

    정제하기 전에 **무엇이 얼마나 망가졌는지** 파악합니다.
    세 파일을 읽고 아래를 확인해 표로 정리하세요.
    - 각 파일의 행 수, 컬럼별 dtype
    - 숫자여야 하는데 문자열로 읽힌 컬럼
    - 컬럼별 결측 수와 비율
    - `station_id`, `log_id` 의 중복 건수
    - `charger_type`, `region_code`, `payment_method` 의 고유값 목록
"""

import pandas as pd
import pymysql
from






